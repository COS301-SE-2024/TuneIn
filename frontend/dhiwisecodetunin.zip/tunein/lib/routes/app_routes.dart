import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/create_new_password_screen/create_new_password_screen.dart';
import '../presentation/forgot_password_screen/forgot_password_screen.dart';
import '../presentation/incorrect_code_screen/incorrect_code_screen.dart';
import '../presentation/login_other_screen/login_other_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/login_streaming_screen/login_streaming_screen.dart';
import '../presentation/make_streaming_account_screen/make_streaming_account_screen.dart';
import '../presentation/otp_verification_for_forgot_password_screen/otp_verification_for_forgot_password_screen.dart';
import '../presentation/otp_verification_for_login_screen/otp_verification_for_login_screen.dart';
import '../presentation/otp_verification_for_register_screen/otp_verification_for_register_screen.dart';
import '../presentation/password_changed_screen/password_changed_screen.dart';
import '../presentation/register_other_screen/register_other_screen.dart';
import '../presentation/register_screen/register_screen.dart';
import '../presentation/register_streaming_screen/register_streaming_screen.dart';
import '../presentation/welcome_screen/welcome_screen.dart';

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String welcomeScreen = '/welcome_screen';

  static const String registerScreen = '/register_screen';

  static const String loginStreamingScreen = '/login_streaming_screen';

  static const String loginOtherScreen = '/login_other_screen';

  static const String loginScreen = '/login_screen';

  static const String otpVerificationForLoginScreen = '/otp_verification_for_login_screen';

  static const String forgotPasswordScreen = '/forgot_password_screen';

  static const String otpVerificationForForgotPasswordScreen = '/otp_verification_for_forgot_password_screen';

  static const String incorrectCodeScreen = '/incorrect_code_screen';

  static const String createNewPasswordScreen = '/create_new_password_screen';

  static const String passwordChangedScreen = '/password_changed_screen';

  static const String registerStreamingScreen = '/register_streaming_screen';

  static const String registerOtherScreen = '/register_other_screen';

  static const String otpVerificationForRegisterScreen = '/otp_verification_for_register_screen';

  static const String makeStreamingAccountScreen = '/make_streaming_account_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static final Map<String, WidgetBuilder> routes = <String, WidgetBuilder>{
    welcomeScreen: (BuildContext context) => const WelcomeScreen(),
    registerScreen: (BuildContext context) => const RegisterScreen(),
    loginStreamingScreen: (BuildContext context) => const LoginStreamingScreen(),
    loginOtherScreen: (BuildContext context) => const LoginOtherScreen(),
    loginScreen: (BuildContext context) => const LoginScreen(),
    otpVerificationForLoginScreen: (BuildContext context) => const OtpVerificationForLoginScreen(),
    forgotPasswordScreen: (BuildContext context) => const ForgotPasswordScreen(),
    otpVerificationForForgotPasswordScreen: (BuildContext context) => const OtpVerificationForForgotPasswordScreen(),
    incorrectCodeScreen: (BuildContext context) => const IncorrectCodeScreen(),
    createNewPasswordScreen: (BuildContext context) => const CreateNewPasswordScreen(),
    passwordChangedScreen: (BuildContext context) => const PasswordChangedScreen(),
    registerStreamingScreen: (BuildContext context) => const RegisterStreamingScreen(),
    registerOtherScreen: (BuildContext context) => const RegisterOtherScreen(),
    otpVerificationForRegisterScreen: (BuildContext context) => const OtpVerificationForRegisterScreen(),
    makeStreamingAccountScreen: (BuildContext context) => const MakeStreamingAccountScreen(),
    appNavigationScreen: (BuildContext context) => const AppNavigationScreen(),
    initialRoute: (BuildContext context) => WelcomeScreen()
  };
}
