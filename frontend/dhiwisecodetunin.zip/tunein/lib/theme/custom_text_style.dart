import 'package:flutter/material.dart';
import '../core/app_export.dart';

extension on TextStyle { 
  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
}

  TextStyle get urbanist {
    return copyWith(
      fontFamily: 'Urbanist',
    );
  }
}

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific for font families
class CustomTextStyles {
// Body text style
  static get bodyLargeOnErrorContainer => theme.textTheme.bodyLarge!.copyWith(
        color: theme.colorScheme.onErrorContainer,
      );
  static get bodyMediumBluegray300=> theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blueGray300,
      );

  static get bodySmall10 => theme.textTheme.bodySmall!.copyWith(
        fontSize: 10.fsize,
);
  

  // Headline text style
  static get headlineLargeGray900 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.gray900,
        fontSize: 30.fsize,
  );

  // Label text style
  static get labelLargeGray60001 => theme.textTheme.labelLarge!.copyWith (
    color: appTheme.gray60001,
    FontWeight: FontWeight.w600,
  );
  // Title text style
  static get titleMediumBluegray400 => theme.textTheme.titleMedium!.copyWith( 
    color: appTheme.blueGray400,
  fontWeight: FontWeight.w500,
  );

  static get titleMediumBluegray40001 => theme.textTheme.titleMedium!.copyWith( 
    color: appTheme.blueGray40001,
  fontWeight: FontWeight.w500,
  );

  static get titleMediumGray900 => theme.textTheme.titleMedium!.copyWith(
  color: appTheme.gray900,
  );

  static get titleMediumPrimary => theme.textTheme.titleMedium!.copyWith( 
    color: theme.colorscheme.primary,
  FontWeight: FontWeight,w700,
  );
  
  static get titleMediumPrimary_1 => theme.textTheme.titleMedium!.copyWith( 
    color: theme.colorscheme.primary,
  );

  static get titleSmallBluegray400 => theme.textTheme.titlesmall!.copyWith( 
    color: appTheme.blueGray400,
  );

  static get titleSmallBluegray40002 => theme.textTheme.titleSmall!.copyWith( 
    color: appTheme.blueGray40002,
  fontWeight: FontWeight.w700,
  );

  static get titleSmallErrorContainer => theme.textTheme.titlesmall!.copyWith( 
    color: theme.colorscheme.errorContainer,
  fontWeight: FontWeight.w700,
  );

  static get titlesmallGray60001 => theme.textTheme.titleSmall!.copyWith(
  color: appTheme.gray60001,
  fontSize: 14.fsize,
  fontWeight: FontWeight.w600,
  );

  static get titleSmallGray900 => theme.textTheme.titleSmall!.copyWith( 
    color: appTheme.gray900,
  fontWeight: FontWeight.w600,
  );

  static get titleSmallGray900_1 => theme.textTheme.titleSmall!.copyWith( 
    color: appTheme.gray900,
  );
  
  static get titleSmallSemiBold => theme.textTheme.titleSmall!.copyWith( 
    fontSize: 14.fsize,
  fontWeight: FontWeight.w600,
  );

  static get titleSmallUrbanist =>
    theme.textTheme.titleSmall!.urbanist.copyWith(
      fontWeight: FontWeight.w700,
  );


  static get titleSmallUrbanistBold =>
    theme.textTheme.titleSmall!.urbanist.copyWith(
      fontWeight: FontWeight.w700,
    );

  }