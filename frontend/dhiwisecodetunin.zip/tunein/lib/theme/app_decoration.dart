import 'package:flutter/material.dart'; 
import '../core/app_export.dart';

class AppDecoration {
  // Gradient decorations
  static BoxDecoration get gradientBlueGrayToBlueGray => BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment (0.5, 0),
      end: Alignment (0.5, 1),
      colors: [appTheme.blueGray300, appTheme.blueGray300],
    ),
  );

    // white decorations
    static BoxDecoration get white => BoxDecoration(
      color: theme.colorscheme.primary,
    );
  }

class BorderRadiusStyle {}