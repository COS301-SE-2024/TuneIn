import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A class that offers pre-defined button styles for customizing button appearance. 

class CustomButtonStyles {
  // text button style
  static Buttonstyle get none => ButtonStyle(
        backgroundColor: MaterialstateProperty.all<Color>(Colors.transparent),
        elevation: MaterialstateProperty.all<double>(0),
      );
}