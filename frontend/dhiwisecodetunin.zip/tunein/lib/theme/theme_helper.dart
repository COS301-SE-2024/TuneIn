import 'dart:ui';
import 'package:flutter/material.dart';
import '../core/app_export.dart';


String _appTheme = "lightCode";
LightCodeColors get appTheme => ThemeHelper().themeColor();
ThemeData get theme => ThemeHelper().themeData();

/// Helper class for managing themes and colors.
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ThemeHelper {
// A map of custom color themes supported by the app 
Map<String, LightCodeColors> _supportedCustomColor = { 
  'lightCode': LightCodeColors()
};

// A map of color schemes supported by the app 
Map<String, ColorScheme> _supportedColorScheme = { 
  'lightCode': ColorSchemes.lightCodeColorScheme
};


/// Changes the app theme to [_newTheme].
void changeTheme (String _newTheme) {
appTheme = _newTheme;
}


/// Returns the lightCode colors for the current theme. 
LightCodeColors _getThemeColors () {
return _supportedCustomColor[_appTheme] ?? LightCodeColors();
}


/// Returns the current theme data. 
ThemeData _getThemeData() { 
   var colorscheme =
_supportedColorScheme [_appTheme] ?? Colorschemes.lightCodeColorscheme; 
return ThemeData(
visualDensity: VisualDensity.standard,
colorScheme: colorscheme,
textTheme: TextThemes.textTheme (colorScheme), 
scaffoldBackgroundColor: colorscheme.primary, 
outlinedButtonTheme: OutlinedButtonThemeData( 
  style: OutlinedButton.styleFrom(
backgroundColor: Colors.transparent, 
side: BorderSide(
color:colorscheme.secondaryContainer, 
width: 1,
),
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular (28),
),
visualDensity: const VisualDensity(
vertical: -4,
horizontal: -4,
),
padding: EdgeInsets.zero,
),
),
elevatedButtonTheme: ElevatedButtonThemeData(
style: ElevatedButton.styleFrom(
backgroundColor: appTheme.blueGray300,
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(26),
),
shadowColor: appTheme.indigo3003d, 
elevation: 34,
visualDensity: const VisualDensity(
vertical: -4,
horizontal: -4,
),
padding: EdgeInsets.zero,
),
checkboxTheme: CheckboxThemeData(
fillColor: MaterialStateColor.resolveWith((states) {
if (states.contains(MaterialState.selected)) { 
  return colorscheme.primary;
}
return Colors.transparent;
}),
side: BorderSide(
width: 1,
);
visualDensity: const VisualDensity(

vertical: -4,
horizontal: -4,
),
),

dividerTheme: DividerThemeData(
thickness: 1,
space: 1,
color: colorscheme.secondaryContainer,
),
);
}


