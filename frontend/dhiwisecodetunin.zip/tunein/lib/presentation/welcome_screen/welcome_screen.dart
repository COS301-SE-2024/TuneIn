// import 'package:flutter/material.dart'; 
// import "../../core/app_export.dart';
// import '../../widgets/custom_elevated_button.dart'; 
// import '../../widgets/custom_outlined_button.dart';


// class WelcomeScreen extends StatelessWidget { 
//   const WelcomeScreen({Key? key})
//       : super(
//         key: key,
//       );

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         body: SizedBox(
//           width: double.maxFinite,
//           child: Column(
//             children: [
//               _buildWelcomeImage(context),
//               SizedBox(height: 19.v),
//               Text(
//                 "Logo",
//                 style: CustomTextstyles.titleSmallUrbanist,
//               ),              
//               SizedBox(height: 20.v),
//               Text(
//                 "TuneIn",
//                 style: theme.textTheme.headlineSmall,
//               ),                      
//               SizedBox(height: 87.v), 
//               CustomElevatedButton(
//               height: 56.v, 
//               text: "Login",
//               margin: EdgeInsets.symmetric (horizontal: 31.h),
//               buttonTextStyle: CustomTextstyles.titleMediumPrimary_1,
//               onPressed: () {
//                 onTapLogin(context);
//                 },
//               ),                         
//               SizedBox(height: 17.v),
//               CustomoutlinedButton(
//                 text: "Register",
//                 margin: EdgeInsets.symmetric (horizontal: 31.h),
//                 buttonTextStyle: CustomTextstyles.titleMediumGray900,
//                 onPressed: () {
//                   onTapRegister(context);
//                 },                
//               ),
//               SizedBox(height: 5.v)
//             ],
//           ),
//         ),
//       ),
//     );
//   }



//   /// Section Widget
//   Widget _buildWelcomeImage(BuildContext context) {
//     return Container(
//       width: double.maxFinite,
//       padding: EdgeInsets.symmetric(
//         horizontal: 148.h,
//         vertical: 157.V,
//       ),
//       decoration: AppDecoration.gradientBlueGrayToBlueGray,
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start, 
//         mainAxisAlignment: MainAxisAlignment.center, 
//         children: [
//             SizedBox(height: 19.v),
//             CustomImageView(
//               imagePath: ImageConstant.imgUser,
//               height: 64.v,
//               width: 80.h,
//             )
//           ],
//         ),
//       );
//     }
 
 
//   /// Navigates to the loginStreamingScreen when the action is triggered. 
//   onTapLogin(BuildContext context) {
//     Navigator.pushNamed (context, AppRoutes.loginstreamingScreen);
//   }
//   /// Navigates to the registerStreamingScreen when the action is triggered. 
//   onTapRegister (BuildContext context) {
//   Navigator.pushNamed (context, AppRoutes, registerStreamingScreen);
//   }
// }