// ignore_for_file: must_be_immutable 
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// Welcome images
  static String imgUser = '$imagePath/img_user.svg';

// Common images
  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';

}
